// Cambiar color de fondo al cargar la página
document.getElementById("curso1").style.backgroundColor = "#99ccff";
document.getElementById("curso2").style.backgroundColor = "#cc99ff";
document.getElementById("curso3").style.backgroundColor = "#99ff99";
